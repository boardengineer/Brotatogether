extends "res://ui/menus/run/weapon_selection.gd"
# Mouse-driven co-op weapon selection, matching the character screen (shared logic
# in coop_mouse_select.gd):
#   * Click a player's panel to make that slot active (outlined in its color).
#   * Click a weapon in a player's inventory to pick it for them.
# The weapon screen has one inventory PER player with element signals bound to the
# inventory index, so a mouse pick routes to that column's player.
#
# It also keeps CoopService.listening_for_inputs true: the character screen runs
# with it on, but the weapon screen leaves it off, which makes each
# FocusEmulator._input swallow every mouse click before the weapon buttons or this
# node ever see it. It flips false naturally once all slots have picked.

const Coop = preload("res://mods-unpacked/Pasha-AutoBattler/extensions/ui/menus/run/coop_mouse_select.gd")

var _active_outline = null


func _ready() -> void:
	_active_outline = Coop.make_outline()
	add_child(_active_outline)
	Coop.enable_mouse_grid(self, RunData.is_coop_run)
	if RunData.is_coop_run:
		CoopService.listening_for_inputs = true
	call_deferred("_autoplay_select")


func _input(event: InputEvent) -> void:
	._input(event)
	if Coop.try_panel_click(self, event):
		get_tree().set_input_as_handled()


func _process(delta: float) -> void:
	._process(delta)
	Coop.update_outline(self, _active_outline)
	if RunData.is_coop_run and not _all_selected():
		CoopService.listening_for_inputs = true


func _all_selected() -> bool:
	for i in range(RunData.get_player_count()):
		if not _has_player_selected[i]:
			return false
	return true


func _set_base_ui_player_count(count: int, is_coop_run: bool, initialize: bool = false) -> void:
	._set_base_ui_player_count(count, is_coop_run, initialize)
	Coop.enable_mouse_grid(self, is_coop_run)


func _on_element_pressed(element: InventoryElement, inventory_player_index: int) -> void:
	Coop.route_to(element, inventory_player_index)
	._on_element_pressed(element, inventory_player_index)


func _on_element_focused(element: InventoryElement, inventory_player_index: int, displayPanelData: bool = true) -> void:
	# With bots present, a hover must not wipe an already-confirmed weapon: the base
	# focus handler unconditionally nulls _player_weapons[pi] and clears the selection.
	# Skip it for a slot that has already chosen -- a click still changes the pick.
	if Coop.only_p1_is_human():
		var pi = FocusEmulatorSignal.get_player_index(element)
		if pi >= 0 and pi < _player_weapons.size() and _player_weapons[pi] != null:
			return
	Coop.route_to(element, inventory_player_index)
	._on_element_focused(element, inventory_player_index, displayPanelData)


# --- Hands-off selection (enable_autoplay_selection) -----------------------------------------
# Deferred from _ready, after a short stabilisation. Options are the unlocked elements of the
# first inventory; a registered decision provider (chat votes) picks, else random.
const AUTOPLAY_WAIT = 1.0
var _autoplay_done = false


func _autoplay_enabled() -> bool:
	var opts = get_node_or_null("/root/AutobattlerOptions")
	return opts != null and opts.enable_autobattler and ("enable_autoplay_selection" in opts) \
			and opts.enable_autoplay_selection


func _autoplay_elements(inv_index: int) -> Array:
	var out = []
	var invs = _get_inventories()
	if inv_index >= invs.size() or invs[inv_index] == null:
		return out
	for el in invs[inv_index].get_children():
		if not (el is InventoryElement) or el.is_random or el.is_special or el.item == null:
			continue
		if ("is_locked" in el) and el.is_locked:
			continue
		if ("disabled" in el) and el.disabled:
			continue
		out.push_back(el)
	return out


func _autoplay_select() -> void:
	if _autoplay_done or not _autoplay_enabled():
		return
	_autoplay_done = true
	yield(get_tree().create_timer(AUTOPLAY_WAIT), "timeout")
	if not is_inside_tree():
		return
	var pi = 0
	if pi < _has_player_selected.size() and _has_player_selected[pi]:
		return
	var els = _autoplay_elements(pi)
	if els.empty():
		return
	var options = []
	for el in els:
		options.push_back({"id": str(el.item.my_id), "label": tr(el.item.name),
			"icon": {"game": "brotato", "kind": "weapon", "id": str(el.item.my_id)},
			"meta": {"advisor_score": 0.0}})
	var opts = get_node_or_null("/root/AutobattlerOptions")
	var choice = opts.ask_provider("weapon", options, {"player": pi, "title": "Pick a starting weapon"})
	if choice is GDScriptFunctionState:
		choice = yield(choice, "completed")
	if not is_inside_tree() or (pi < _has_player_selected.size() and _has_player_selected[pi]):
		return
	if choice < 0 or choice >= els.size():
		choice = opts.best_by_advisor(options)
	var el = els[choice]
	if not is_instance_valid(el):
		return
	print("BOTLOG AUTOPLAY weapon=%s" % str(el.item.my_id))
	_on_element_focused(el, pi)
	_on_element_pressed(el, pi)
