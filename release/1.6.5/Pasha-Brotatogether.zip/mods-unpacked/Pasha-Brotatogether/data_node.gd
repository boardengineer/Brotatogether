extends Node

var data = {}
