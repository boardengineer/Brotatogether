extends Node

signal setting_changed(setting_name, value, mod_name)

# Runtime option store for the AutoBattler mod. Values are mirrored as plain vars
# for short reads, persisted to a ConfigFile directly. When the optional
# dami-ModOptions mod is present, the ones declared in manifest config_schema --
# Enable Bot, Autoshop, Evolution Pickups, Evolution Fruit Pull and Guard Dino Egg --
# are exposed in its panel and kept in sync here; nothing else is surfaced. The two toggles are also
# flipped via the hotkey below and the per-bot AUTO-SHOP panel toggle.

var enable_autobattler : bool = false
const ENABLE_AUTOBATTLER_OPTION_NAME = "ENABLE_AUTOBATTLER"

# Automatic shopping for the pure-AutoBattler mode (every slot a bot). Default
# OFF; the WaveLab test harness sets it true explicitly. Co-op bot slots do NOT
# use this flag -- each opts in via CoopService.autoshop_by_index (its panel toggle).
var enable_autoshop : bool = false
const ENABLE_AUTOSHOP_OPTION_NAME = "ENABLE_AUTOSHOP"

var enable_ai_visuals : bool = false
const ENABLE_AI_VISUALS_OPTION_NAME = "ENABLE_AI_VISUALS"

# Primal Dread evolution pickups: how the bot treats Meca/Mutant Fruit (they push
# the Evolution stat +1/-1 and never heal) and the path drops, Mutation Fruit and
# Meca Parts. The strings are the ModOptions dropdown labels, so they double as the
# stored value. Avoid walks around both fruits; Ignore neither seeks nor avoids
# anything; a path seeks its own fruit and drop and avoids the other side's fruit;
# Auto path takes the first side it reaches and then plays that path.
const EVOLUTION_AVOID = "Avoid"
const EVOLUTION_IGNORE = "Ignore"
const EVOLUTION_MUTATION = "Mutation path"
const EVOLUTION_MECHA = "Mecha path"
const EVOLUTION_AUTO = "Auto path"      # first side reached, then commit
const EVOLUTION_MODES = [EVOLUTION_AVOID, EVOLUTION_IGNORE, EVOLUTION_MUTATION, EVOLUTION_MECHA, EVOLUTION_AUTO]
var evolution_pickups : String = EVOLUTION_AVOID
const EVOLUTION_PICKUPS_OPTION_NAME = "EVOLUTION_PICKUPS"
# How hard a path mode goes for its own fruit, in the arbiter's HP-equivalent reward
# units (a full-heal fruit is 12). 0 = never seek it.
const EVOLUTION_SEEK_DEFAULT = 15.0
var evolution_seek : float = EVOLUTION_SEEK_DEFAULT
const EVOLUTION_SEEK_OPTION_NAME = "EVOLUTION_SEEK"

# Primal Dread Dino Egg item: stay near the egg and kill what is attacking it.
var guard_dino_egg : bool = true
const GUARD_DINO_EGG_OPTION_NAME = "GUARD_DINO_EGG"

# Arbiter weight overrides harvested from --arb-<name>=<value> startup args.
var arb_overrides : Dictionary = {}

# --- Decision provider seam ---------------------------------------------------------------
# Another mod (e.g. Pasha-VoteController: chat votes) may register a node here to be asked
# BEFORE the bot decides: shop buy/reroll/done rounds, level-up upgrades, item take/discard,
# and -- with enable_autoplay_selection -- character, weapon and difficulty. Contract:
#   decide(kind: String, options: Array, ctx: Dictionary) -> int
# a coroutine or plain function returning the chosen option index, or -1 for "no result:
# use the advisor / random fallback". kind is one of "shop" "levelup" "item" "character"
# "weapon" "difficulty". Every option is {id, label, icon?, meta} and every meta carries
# advisor_score so the fallback is a one-liner (best score; random where scores tie at 0).
# With no provider registered the bot behaves exactly as before.
var decision_provider = null
# Bot also picks character / weapon / difficulty (hands-off runs). --autoplay sets it.
var enable_autoplay_selection : bool = false


func get_provider():
	if decision_provider != null and is_instance_valid(decision_provider) \
			and decision_provider.has_method("decide"):
		return decision_provider
	return null


# Call-site helper: ask the provider, yielding if it is a coroutine. -1 when there is no
# provider or it declines. Callers use the same pattern on this function:
#   var r = opts.ask_provider(kind, options, ctx)
#   if r is GDScriptFunctionState: r = yield(r, "completed")
func ask_provider(kind: String, options: Array, ctx: Dictionary = {}) -> int:
	var p = get_provider()
	if p == null or options.empty():
		return -1
	var r = p.decide(kind, options, ctx)
	if r is GDScriptFunctionState:
		r = yield(r, "completed")
	if typeof(r) != TYPE_INT and typeof(r) != TYPE_REAL:
		return -1
	var idx = int(r)
	if idx < 0 or idx >= options.size():
		return -1
	return idx


# Fallback pick: highest meta.advisor_score; ties (and all-zero scores) go random so a
# provider-less "character" decision does not always land on the first element.
static func best_by_advisor(options: Array) -> int:
	var best = -1
	var best_score = -1e18
	var tied = []
	for i in options.size():
		var meta = options[i].get("meta", {})
		var sc = float(meta.get("advisor_score", 0.0))
		if sc > best_score:
			best_score = sc
			best = i
			tied = [i]
		elif sc == best_score:
			tied.push_back(i)
	if tied.size() > 1:
		return tied[randi() % tied.size()]
	return best

var enable_ai_marker : bool = true
const ENABLE_AI_MARKER_OPTION_NAME = "ENABLE_AI_MARKER"

var enable_smoothing : bool = true
const ENABLE_SMOOTHING_OPTION_NAME = "ENABLE_SMOOTHING"

var smoothing_speed : float = 1
const SMOOTHING_SPEED_OPTION_NAME = "SMOOTHING_SPEED"

var item_weight : float = .5
const ITEM_WEIGHT_OPTION_NAME = "ITEM_WEIGHT"

var projectile_weight : float = 2
const PROJECTILE_WEIGHT_OPTION_NAME = "PROJECTILE_WEIGHT"

var tree_weight : float = 2
const TREE_WEIGHT_OPTION_NAME = "TREE_WEIGHT"

var boss_weight : float = 3
const BOSS_WEIGHT_OPTION_NAME = "BOSS_WEIGHT"

var bumper_weight : float = 2
const BUMPER_WEIGHT_OPTION_NAME = "BUMPER_WEIGHT"

var egg_weight : float = 5
const EGG_WEIGHT_OPTION_NAME = "EGG_WEIGHT"

var bumper_distance : float = 300
const BUMPER_DISTANCE_OPTION_NAME = "BUMPER_DISTANCE"

const DEFAULT_COOLDOWN = .2
var _last_ss_ms = 0   # OS.get_ticks_msec of the last Shift+Space toggle (debounce)
var option_cooldown = DEFAULT_COOLDOWN

const MOD_NAME = "Pasha-AutoBattler"
const CONFIG_FILENAME = "user://pasha-botato-options.cfg"
const CONFIG_SECTION = "options"


func _ready():
	reset_defaults()
	load_mod_options()
	# When ModOptions is installed, let its panel own the two exposed toggles: read
	# their current values and listen for live changes. No-op without the mod.
	_connect_modoptions()

	# Benchmarks pick the controller on the command line; it must win over the
	# saved config so a bench run never inherits whatever was toggled by hand.
	var startup_args = Utils.get_startup_arguments()
	for key in startup_args.keys():
		if key.begins_with("arb-"):
			arb_overrides[key.substr(4)] = float(startup_args[key])
	if startup_args.has("autoplay"):
		enable_autoplay_selection = true


# --- Optional dami-ModOptions integration (Enable Bot + Autoshop only) --------
func _modoptions_interface():
	var ml = get_node_or_null("/root/ModLoader")
	if ml == null or not ml.has_node("dami-ModOptions/ModsConfigInterface"):
		return null
	return ml.get_node("dami-ModOptions/ModsConfigInterface")


func _connect_modoptions() -> void:
	var iface = _modoptions_interface()
	if iface == null:
		return
	# Apply the panel's stored values for the two toggles we expose.
	if iface.has_method("get_settings"):
		var s = iface.get_settings(MOD_NAME)
		if typeof(s) == TYPE_DICTIONARY:
			if s.has(ENABLE_AUTOBATTLER_OPTION_NAME):
				enable_autobattler = s[ENABLE_AUTOBATTLER_OPTION_NAME]
			if s.has(ENABLE_AUTOSHOP_OPTION_NAME):
				enable_autoshop = s[ENABLE_AUTOSHOP_OPTION_NAME]
	# The rest are the other way round: ModOptions never saves them, so our own config
	# owns the values and the panel is told what to show.
	_sync_modoptions_enum(iface, EVOLUTION_PICKUPS_OPTION_NAME, evolution_pickups)
	_sync_modoptions_value(iface, EVOLUTION_SEEK_OPTION_NAME, evolution_seek)
	_sync_modoptions_value(iface, GUARD_DINO_EGG_OPTION_NAME, guard_dino_egg)
	if not iface.is_connected("setting_changed", self, "setting_changed"):
		var _e = iface.connect("setting_changed", self, "setting_changed")


# An unknown string (a hand-edited config, a label renamed in a later version) keeps
# the current mode rather than silently switching the bot to some other behaviour.
func _set_evolution_pickups(value) -> void:
	if EVOLUTION_MODES.has(str(value)):
		evolution_pickups = str(value)


# ModOptions builds a dropdown from mod_configs["enum_<key>"] but writes a change to
# mod_configs["<key>"], and the panel is rebuilt with every wave's pause menu -- so
# without this it shows the default again each wave (the bot itself keeps the choice).
func _sync_modoptions_enum(iface, key: String, value) -> void:
	if iface == null or not ("mod_configs" in iface) or not iface.mod_configs.has(MOD_NAME):
		return
	if iface.mod_configs[MOD_NAME].has("enum_" + key):
		iface.mod_configs[MOD_NAME]["enum_" + key] = value


# Sliders and checkboxes read and write the plain key, so only the startup value needs
# pushing (the panel's own copy is the manifest default, rebuilt every launch).
func _sync_modoptions_value(iface, key: String, value) -> void:
	if iface == null or not ("mod_configs" in iface) or not iface.mod_configs.has(MOD_NAME):
		return
	if iface.mod_configs[MOD_NAME].has(key):
		iface.mod_configs[MOD_NAME][key] = value


# Called by ModOptions when a panel setting changes. We only own the manifest's keys.
func setting_changed(key: String, value, mod) -> void:
	if mod != MOD_NAME:
		return
	if key == ENABLE_AUTOBATTLER_OPTION_NAME:
		enable_autobattler = value
		# Re-fire our own signal so the player's ai_icon marker refreshes when the
		# toggle is flipped from the ModOptions panel (not just the hotkey). This
		# does not re-enter here -- this handler listens to ModOptions' signal, not
		# ours; ours drives only the player marker.
		emit_signal("setting_changed", key, value, MOD_NAME)
	elif key == ENABLE_AUTOSHOP_OPTION_NAME:
		enable_autoshop = value
	elif key == EVOLUTION_PICKUPS_OPTION_NAME:
		_set_evolution_pickups(value)
		_sync_modoptions_enum(_modoptions_interface(), key, evolution_pickups)
		save_configs()
	elif key == EVOLUTION_SEEK_OPTION_NAME:
		evolution_seek = max(float(value), 0.0)
		save_configs()
	elif key == GUARD_DINO_EGG_OPTION_NAME:
		guard_dino_egg = bool(value)
		save_configs()


# Push a hotkey/programmatic change back into the ModOptions panel so its checkbox
# reflects the new state. No-op without the mod.
func _push_modoption(key: String, value) -> void:
	var iface = _modoptions_interface()
	if iface == null:
		return
	if ("mod_configs" in iface) and iface.mod_configs.has(MOD_NAME):
		iface.mod_configs[MOD_NAME][key] = value
	if iface.has_method("on_setting_changed"):
		iface.on_setting_changed(key, value, MOD_NAME)


func _input(event):
	# `pressed` + `echo` guards stop a toggle firing twice per press / on auto-repeat.
	if event is InputEventKey and event.pressed and not event.echo:
		if event.shift and event.scancode == KEY_SPACE:
			# Debounce with a wall-clock timestamp -- Shift+Space arrives as a double
			# event per physical press (~0.2-0.3s apart), which the old delta cooldown
			# let slip through, double-toggling to no net change.
			var now = OS.get_ticks_msec()
			if now - _last_ss_ms >= 350:
				_last_ss_ms = now
				enable_autobattler = not enable_autobattler
				# Notify our own listeners (the player's ai_icon marker updates from
				# this) AND reflect into the ModOptions panel.
				emit_signal("setting_changed", ENABLE_AUTOBATTLER_OPTION_NAME, enable_autobattler, MOD_NAME)
				_push_modoption(ENABLE_AUTOBATTLER_OPTION_NAME, enable_autobattler)
				save_configs()


func _process(delta):
	option_cooldown -= delta


func load_mod_options():
	var config = ConfigFile.new()
	if config.load(CONFIG_FILENAME) != OK:
		return
	enable_autobattler = config.get_value(CONFIG_SECTION, ENABLE_AUTOBATTLER_OPTION_NAME, false)
	enable_autoshop    = config.get_value(CONFIG_SECTION, ENABLE_AUTOSHOP_OPTION_NAME, false)
	enable_ai_visuals  = config.get_value(CONFIG_SECTION, ENABLE_AI_VISUALS_OPTION_NAME, false)
	_set_evolution_pickups(config.get_value(CONFIG_SECTION, EVOLUTION_PICKUPS_OPTION_NAME, EVOLUTION_AVOID))
	evolution_seek     = max(float(config.get_value(CONFIG_SECTION, EVOLUTION_SEEK_OPTION_NAME, EVOLUTION_SEEK_DEFAULT)), 0.0)
	guard_dino_egg     = bool(config.get_value(CONFIG_SECTION, GUARD_DINO_EGG_OPTION_NAME, true))
	enable_ai_marker   = config.get_value(CONFIG_SECTION, ENABLE_AI_MARKER_OPTION_NAME, true)
	enable_smoothing   = config.get_value(CONFIG_SECTION, ENABLE_SMOOTHING_OPTION_NAME, true)
	smoothing_speed    = config.get_value(CONFIG_SECTION, SMOOTHING_SPEED_OPTION_NAME, 1)
	item_weight        = config.get_value(CONFIG_SECTION, ITEM_WEIGHT_OPTION_NAME, .5)
	projectile_weight  = config.get_value(CONFIG_SECTION, PROJECTILE_WEIGHT_OPTION_NAME, 2)
	tree_weight        = config.get_value(CONFIG_SECTION, TREE_WEIGHT_OPTION_NAME, 2)
	boss_weight        = config.get_value(CONFIG_SECTION, BOSS_WEIGHT_OPTION_NAME, 3)
	bumper_weight      = config.get_value(CONFIG_SECTION, BUMPER_WEIGHT_OPTION_NAME, 2)
	egg_weight         = config.get_value(CONFIG_SECTION, EGG_WEIGHT_OPTION_NAME, 5)
	bumper_distance    = config.get_value(CONFIG_SECTION, BUMPER_DISTANCE_OPTION_NAME, 300)


func save_configs() -> void:
	var config = ConfigFile.new()
	config.set_value(CONFIG_SECTION, ENABLE_AUTOBATTLER_OPTION_NAME, enable_autobattler)
	config.set_value(CONFIG_SECTION, ENABLE_AUTOSHOP_OPTION_NAME    , enable_autoshop)
	config.set_value(CONFIG_SECTION, ENABLE_AI_VISUALS_OPTION_NAME , enable_ai_visuals)
	config.set_value(CONFIG_SECTION, EVOLUTION_PICKUPS_OPTION_NAME , evolution_pickups)
	config.set_value(CONFIG_SECTION, EVOLUTION_SEEK_OPTION_NAME    , evolution_seek)
	config.set_value(CONFIG_SECTION, GUARD_DINO_EGG_OPTION_NAME    , guard_dino_egg)
	config.set_value(CONFIG_SECTION, ENABLE_AI_MARKER_OPTION_NAME  , enable_ai_marker)
	config.set_value(CONFIG_SECTION, ENABLE_SMOOTHING_OPTION_NAME  , enable_smoothing)
	config.set_value(CONFIG_SECTION, SMOOTHING_SPEED_OPTION_NAME   , smoothing_speed)
	config.set_value(CONFIG_SECTION, ITEM_WEIGHT_OPTION_NAME       , item_weight)
	config.set_value(CONFIG_SECTION, PROJECTILE_WEIGHT_OPTION_NAME , projectile_weight)
	config.set_value(CONFIG_SECTION, TREE_WEIGHT_OPTION_NAME       , tree_weight)
	config.set_value(CONFIG_SECTION, BOSS_WEIGHT_OPTION_NAME       , boss_weight)
	config.set_value(CONFIG_SECTION, BUMPER_WEIGHT_OPTION_NAME     , bumper_weight)
	config.set_value(CONFIG_SECTION, EGG_WEIGHT_OPTION_NAME        , egg_weight)
	config.set_value(CONFIG_SECTION, BUMPER_DISTANCE_OPTION_NAME   , bumper_distance)
	config.save(CONFIG_FILENAME)


func reset_defaults() -> void:
	enable_autobattler = false
	enable_autoshop = false
	enable_ai_marker = true
	enable_ai_visuals = false
	enable_smoothing = true
	evolution_pickups = EVOLUTION_AVOID
	evolution_seek = EVOLUTION_SEEK_DEFAULT
	guard_dino_egg = true

	smoothing_speed = 1
	item_weight = 0.5
	projectile_weight = 2.0
	tree_weight = 2.0
	boss_weight = 3.0
	bumper_weight = 2.0
	egg_weight = 5.0
	bumper_distance = 300
