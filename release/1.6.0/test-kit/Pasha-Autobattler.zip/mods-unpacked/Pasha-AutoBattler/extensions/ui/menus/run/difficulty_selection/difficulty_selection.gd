extends "res://ui/menus/run/difficulty_selection/difficulty_selection.gd"
# Mouse-driven danger selection when a lone human is commanding bots: click a
# danger level to pick it. Same fix as the character/weapon screens (shared logic
# in coop_mouse_select) -- enable mouse focus on the difficulty grid, keep
# CoopService.listening_for_inputs true (else the FocusEmulators swallow the
# click), and route the mouse pick to the active slot.

const Coop = preload("res://mods-unpacked/Pasha-AutoBattler/extensions/ui/menus/run/coop_mouse_select.gd")


func _ready() -> void:
	._ready()
	Coop.enable_mouse_grid(self, RunData.is_coop_run)
	Coop.keep_mouse_enabled()
	# Character select leaves current_player_index wherever the F1 bot-add cycling
	# last put it (often a bot slot). Danger is a single shared choice driven by the
	# human, so default it back to the first player on entry.
	if Coop.only_p1_is_human():
		CoopService.current_player_index = 0
	call_deferred("_autoplay_select")


func _process(delta: float) -> void:
	._process(delta)
	Coop.keep_mouse_enabled()


func _set_base_ui_player_count(count: int, is_coop_run: bool, initialize: bool = false) -> void:
	._set_base_ui_player_count(count, is_coop_run, initialize)
	Coop.enable_mouse_grid(self, is_coop_run)


func _on_element_pressed(element: InventoryElement, inventory_player_index: int) -> void:
	Coop.route_to(element, CoopService.current_player_index)
	._on_element_pressed(element, inventory_player_index)


func _on_element_focused(element: InventoryElement, inventory_player_index: int, displayPanelData: bool = true) -> void:
	Coop.route_to(element, CoopService.current_player_index)
	._on_element_focused(element, inventory_player_index, displayPanelData)


# --- Hands-off selection (enable_autoplay_selection) -----------------------------------------
# Deferred from _ready, after a short stabilisation. Options are the unlocked elements of the
# first inventory; a registered decision provider (chat votes) picks, else random.
const AUTOPLAY_WAIT = 1.0
var _autoplay_done = false


func _autoplay_enabled() -> bool:
	var opts = get_node_or_null("/root/AutobattlerOptions")
	return opts != null and opts.enable_autobattler and ("enable_autoplay_selection" in opts) \
			and opts.enable_autoplay_selection


func _autoplay_elements(inv_index: int) -> Array:
	var out = []
	var invs = _get_inventories()
	if inv_index >= invs.size() or invs[inv_index] == null:
		return out
	for el in invs[inv_index].get_children():
		if not (el is InventoryElement) or el.is_random or el.is_special or el.item == null:
			continue
		if ("is_locked" in el) and el.is_locked:
			continue
		if ("disabled" in el) and el.disabled:
			continue
		out.push_back(el)
	return out


func _autoplay_select() -> void:
	if _autoplay_done or not _autoplay_enabled():
		return
	_autoplay_done = true
	yield(get_tree().create_timer(AUTOPLAY_WAIT), "timeout")
	if not is_inside_tree() or difficulty_selected:
		return
	# Only dangers this character has unlocked.
	var max_diff = 0
	var character = RunData.get_player_character(0)
	if character != null:
		var info = ProgressData.get_character_difficulty_info(character.my_id_hash, RunData.current_zone)
		if info != null and ("max_selectable_difficulty" in info):
			max_diff = int(info.max_selectable_difficulty)
	var els = []
	for el in _autoplay_elements(0):
		if ("value" in el.item) and int(el.item.value) <= max_diff:
			els.push_back(el)
	if els.empty():
		return
	var options = []
	for el in els:
		options.push_back({"id": "danger%d" % int(el.item.value), "label": "Danger %d" % int(el.item.value),
			"meta": {"danger": int(el.item.value), "advisor_score": 0.0}})
	var opts = get_node_or_null("/root/AutobattlerOptions")
	var choice = opts.ask_provider("difficulty", options, {"player": 0, "title": "Pick the danger level"})
	if choice is GDScriptFunctionState:
		choice = yield(choice, "completed")
	if not is_inside_tree() or difficulty_selected:
		return
	if choice < 0 or choice >= els.size():
		choice = opts.best_by_advisor(options)
	var el = els[choice]
	if not is_instance_valid(el):
		return
	print("BOTLOG AUTOPLAY danger=%d" % int(el.item.value))
	_on_element_focused(el, 0)
	_on_element_pressed(el, 0)   # starts the run
