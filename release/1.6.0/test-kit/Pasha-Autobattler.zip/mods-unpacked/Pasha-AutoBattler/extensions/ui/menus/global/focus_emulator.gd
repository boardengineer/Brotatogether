extends "res://ui/menus/global/focus_emulator.gd"

const Coop = preload("res://mods-unpacked/Pasha-AutoBattler/extensions/ui/menus/run/coop_mouse_select.gd")


# When there is only ONE human -- a plain solo run OR a lone human commanding F1 bots
# (only_p1_is_human) -- input must not route through the co-op FocusEmulator at all. Vanilla
# leaves this emulator dormant in solo (connected_players empty, _device -1); but the mod
# populates connected_players, activating it. An active emulator swallows the lone human's
# non-whitelisted keys in the shop -- ui_accept (Space, which opens the owned-gear discard/
# combine popup) and ui_select ('e' / lock) get eaten before the shop's own input handles them
# -- and hijacks the mouse's focus. The original solo fix gated only on `not is_coop_run`, but
# a BOT co-op run IS a coop run, so the lone human's Space kept getting swallowed. Gate on
# "at most one human" so the shop's own mouse/keyboard handling runs, exactly like an unmodded
# game. Real co-op (2+ humans) keeps the emulator active.
func _input(event: InputEvent) -> void:
	if not RunData.is_coop_run or Coop.only_p1_is_human():
		return
	._input(event)


# --- Freed-control safety (deterministic combine crash) ----------------------
# In (bot) co-op the mod parks a control in this emulator via
# Utils.focus_player_control() -> set_deferred("focused_control", control). A shop
# COMBINE frees the gear element / owned-item popup button that control points at,
# so focused_control is left dangling. The base emulator only ever null-checks it
# (== null), never is_instance_valid(), so _draw(), the next _clear_focused_control()
# (via _clear_focus_style / _disconnect_focused_control), and the _handle_input
# recovery all dereference the freed control (or a now-stale child index) a few frames
# later -> the hard, backtrace-less segfault the user hit on combine. Guard each such
# dereference so a freed focus is skipped / dropped safely. Combining is a base action;
# the bot only exposed it by parking mouse-hover focus in the co-op emulator.
func _draw() -> void:
	if not is_instance_valid(focused_control):
		return
	._draw()


func _clear_focus_style(control: Control) -> void:
	if control == null or not is_instance_valid(control):
		return
	._clear_focus_style(control)


func _disconnect_focused_control(control: Control) -> void:
	if control == null or not is_instance_valid(control):
		return
	._disconnect_focused_control(control)


# Disable "wrong" players from using input
# Process player change action
func _handle_input(event:InputEvent) -> bool:
	if player_index != CoopService.current_player_index and not get_tree().current_scene.name == "DifficultySelection":
		return false
		
	if event is InputEventKey and event.pressed:
		if event.scancode == KEY_QUOTELEFT:
			CoopService.current_player_index = (CoopService.current_player_index + 1) % CoopService.connected_players.size()
			if get_tree().current_scene.name == "Main":
				update_player_index()
			return true
		
	# If the parked control was freed (e.g. a combine freed the gear element it
	# pointed at), the base recovery runs _focused_parent.get_child(stale_index) on a
	# stale index / freed parent -> crash. Drop the dead focus safely instead (the
	# guarded _clear_focus_style / _disconnect_focused_control above make this safe).
	if focused_control != null and not is_instance_valid(focused_control):
		_clear_focused_control()
		return false

	var result = ._handle_input(event)
	if result and Utils.is_maybe_action_pressed(event, "ui_accept_%s" % _device):
		if get_tree().current_scene.name == "Main":
			update_player_index()
	return result


# Set all devices to the main player's device
func _on_connected_players_updated(connected_players:Array)->void :
	._on_connected_players_updated(connected_players)
	if CoopService.main_player_device == -1:
		CoopService.main_player_device = _device
		CoopService.main_player_index = player_index
	elif CoopService.is_bot_by_index[player_index] or player_index == -1:
		# TODO explains the player_index == -1 check that seems to be load-bearing
		_device = CoopService.main_player_device


# Enable the player change action to bypass is_coop_ui_action check
func _is_coop_ui_action(event:InputEvent)->bool:
	if event is InputEventKey and event.pressed:
		if event.scancode == KEY_QUOTELEFT:
			return true
	return ._is_coop_ui_action(event)


# After hitting accept, the focus controller might no longer accept input,
# In crement the current player to make sure a valid player has focus
func update_player_index() -> void:
	var choosing_players =  $"/root/Main/UI/CoopUpgradesUI"._player_is_choosing
	if not choosing_players[CoopService.current_player_index]:
		for index in choosing_players.size():
			if choosing_players[index]:
				CoopService.current_player_index = index
				return
