extends "res://ui/menus/global/popup_manager.gd"

# The base PopupManager connects each shop container's signals every time connect_*_container is
# called and NEVER disconnects. In the bot co-op shop the setup re-runs (per player, per shop
# refresh), so these get re-connected repeatedly -- the harmless "Signal ... already connected"
# spam -- and, critically, connect_inventory_container can be called on a container whose
# _elements GridContainer has just been FREED (combining rebuilds the gear), where connect() on
# the freed node hard-crashes the game (deterministic crash on combine in co-op, no backtrace).
# Guard every connect with is_instance_valid + is_connected so a freed or already-wired container
# is skipped instead of crashing. Behaviour for a fresh, valid, unconnected container is unchanged.

func _connect_guarded(source: Object, signals: Array, prefix: String) -> void:
	if source == null or not is_instance_valid(source):
		return
	for sig in signals:
		var method = prefix + sig
		if not source.is_connected(sig, self, method):
			var _e = source.connect(sig, self, method)


func connect_inventory_container(container) -> void:
	if container == null or not is_instance_valid(container):
		return
	_connect_guarded(container._elements, \
		["element_hovered", "element_unhovered", "element_focused", "element_unfocused", "element_pressed"], "_on_")


func connect_stats_container(container) -> void:
	_connect_guarded(container, ["stat_focused", "stat_unfocused", "stat_hovered", "stat_unhovered"], "_on_")


func connect_shop_items_container(container) -> void:
	_connect_guarded(container, ["shop_item_focused", "shop_item_unfocused"], "_on_")
