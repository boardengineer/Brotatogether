extends Node

const MOD_DIR = "Pasha-AutoBattler/"

var dir = ""
var ext_dir = ""
var trans_dir = ""

func _init():
	dir = ModLoaderMod.get_unpacked_dir() + MOD_DIR
	ext_dir = dir + "extensions/"
	trans_dir = dir + "translations/"
	
	# Add extensions
	ModLoaderMod.install_script_extension(ext_dir + "main.gd")
	
	ModLoaderMod.install_script_extension(ext_dir + "entities/units/movement_behaviors/player_movement_behavior.gd")
	ModLoaderMod.install_script_extension(ext_dir + "entities/units/player/player.gd")
	
	ModLoaderMod.install_script_extension(ext_dir + "singletons/coop_service.gd")
	ModLoaderMod.install_script_extension(ext_dir + "singletons/input_service.gd")
	ModLoaderMod.install_script_extension(ext_dir + "singletons/cursor_manager.gd")
	ModLoaderMod.install_script_extension(ext_dir + "singletons/progress_data.gd")
	ModLoaderMod.install_script_extension(ext_dir + "singletons/run_data.gd")
	
	ModLoaderMod.install_script_extension(ext_dir + "ui/menus/global/focus_emulator.gd")
	ModLoaderMod.install_script_extension(ext_dir + "ui/menus/global/popup_manager.gd")
	ModLoaderMod.install_script_extension(ext_dir + "ui/menus/ingame/upgrades_ui.gd")
	# base_shop is installed late (see _install_late_extensions).
	ModLoaderMod.install_script_extension(ext_dir + "ui/menus/pages/main_menu.gd")
	ModLoaderMod.install_script_extension(ext_dir + "ui/menus/run/coop_join_panel.gd")
	ModLoaderMod.install_script_extension(ext_dir + "ui/menus/run/character_selection.gd")
	ModLoaderMod.install_script_extension(ext_dir + "ui/menus/run/difficulty_selection/difficulty_selection.gd")
	ModLoaderMod.install_script_extension(ext_dir + "ui/menus/run/weapon_selection.gd")
	
	ModLoaderMod.add_translation(trans_dir + "autobattler_options.en.translation")
	call_deferred("_install_late_extensions")

# Brotato 1.2.0.1 base_shop.gd has `var next_wave := RunData.get_next_wave()`. Compiled during
# ModLoader init, before the RunData autoload exists, that inference fails ("The assigned value
# doesn't have a set type"), base_shop fails to load and the extension is dropped (no autoshop).
# Installed after init the extension applies immediately, once every autoload is in the tree.
func _install_late_extensions():
	ModLoaderMod.install_script_extension(ext_dir + "ui/menus/shop/base_shop.gd")
